// Park Pulse - Main JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initMobileMenu();
    initSmoothScroll();
    initScrollAnimations();
    initCounterAnimation();
    initParallaxEffects();
});

// Mobile menu functionality
function initMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenuBtn && navLinks) {
        mobileMenuBtn.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            mobileMenuBtn.classList.toggle('active');
        });
        
        document.addEventListener('click', function(e) {
            if (!mobileMenuBtn.contains(e.target) && !navLinks.contains(e.target)) {
                navLinks.classList.remove('active');
                mobileMenuBtn.classList.remove('active');
            }
        });
        
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', function() {
                navLinks.classList.remove('active');
                mobileMenuBtn.classList.remove('active');
            });
        });
    }
}

// Smooth scroll for anchor links
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
}

// Scroll reveal animations with staggered delays
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -80px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Feature cards with stagger
    document.querySelectorAll('.feature-card').forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(28px) translateZ(0)';
        card.style.transition = `opacity 0.55s cubic-bezier(0.25, 0.46, 0.45, 0.94) ${index * 0.08}s, transform 0.55s cubic-bezier(0.34, 1.56, 0.64, 1) ${index * 0.08}s`;
        observer.observe(card);
    });
    
    // Stat cards with stagger
    document.querySelectorAll('.stat-card').forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(24px) translateZ(0)';
        card.style.transition = `opacity 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94) ${index * 0.1}s, transform 0.5s cubic-bezier(0.34, 1.56, 0.64, 1) ${index * 0.1}s`;
        observer.observe(card);
    });
    
    // Source cards with stagger
    document.querySelectorAll('.source-card').forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(28px) translateZ(0)';
        card.style.transition = `opacity 0.55s cubic-bezier(0.25, 0.46, 0.45, 0.94) ${index * 0.08}s, transform 0.55s cubic-bezier(0.34, 1.56, 0.64, 1) ${index * 0.08}s`;
        observer.observe(card);
    });
    
    // Section titles
    document.querySelectorAll('.section-title').forEach(title => {
        title.style.opacity = '0';
        title.style.transform = 'translateY(18px) translateZ(0)';
        title.style.transition = 'opacity 0.45s cubic-bezier(0.25, 0.46, 0.45, 0.94), transform 0.45s cubic-bezier(0.34, 1.56, 0.64, 1)';
        observer.observe(title);
    });
}

// Animated counter for stats
function initCounterAnimation() {
    const counters = document.querySelectorAll('.stat-number');
    
    const counterObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !entry.target.classList.contains('counted')) {
                entry.target.classList.add('counted');
                animateCounter(entry.target);
            }
        });
    }, { threshold: 0.5 });
    
    counters.forEach(counter => counterObserver.observe(counter));
}

function animateCounter(element) {
    const text = element.textContent;
    const match = text.match(/([\d,]+)/);
    if (!match) return;
    const target = parseInt(match[1].replace(/,/g, ''));
    const suffix = text.slice(match[1].length);
    const duration = 1800;
    const start = performance.now();

    function easeOutExpo(t) {
        return t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
    }

    function tick(now) {
        const elapsed = now - start;
        const progress = Math.min(elapsed / duration, 1);
        const value = Math.round(easeOutExpo(progress) * target);
        element.textContent = value.toLocaleString() + suffix;
        if (progress < 1) requestAnimationFrame(tick);
    }

    requestAnimationFrame(tick);
}

// Subtle parallax effects
function initParallaxEffects() {
    const hero = document.querySelector('.hero');
    const heroImage = document.querySelector('.hero-image');
    
    if (hero && heroImage && window.innerWidth > 768) {
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const rate = scrolled * 0.3;
            
            if (scrolled < hero.offsetHeight) {
                heroImage.style.transform = `translateY(${rate * 0.2}px)`;
            }
        });
    }
    
    // Mouse move parallax for decorations
    const decorations = document.querySelectorAll('.hero-decoration');
    if (decorations.length > 0 && window.innerWidth > 768) {
        document.addEventListener('mousemove', (e) => {
            const mouseX = e.clientX / window.innerWidth - 0.5;
            const mouseY = e.clientY / window.innerHeight - 0.5;
            
            decorations.forEach((dec, index) => {
                const speed = (index + 1) * 20;
                dec.style.transform = `translate(${mouseX * speed}px, ${mouseY * speed}px)`;
            });
        });
    }
}
