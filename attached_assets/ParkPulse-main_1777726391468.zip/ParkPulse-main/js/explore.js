// Park Pulse - Explore Page JavaScript

// Global state
let map;
let markers = [];
let allParks = [];
let filteredParks = [];

// Overlay layers
let fountainLayer = null;
let transportLayer = null;
let treeClusterLayer = null;
let toiletLayer = null;
let blacktownLayer = null;
let toiletsLoaded = false;
let toiletsLoading = false;

// All searchable overlay items (fountains, transport, blacktown)
let allOverlayItems = []; // { name, subtitle, lat, lng, layer, type }

const TREE_ZOOM_THRESHOLD = 15;

let currentFilters = {
    playground: false,
    sports: false,
    iconic: false,
    neighbourhood: false,
    pocket: false,
    sportsfield: false,
    fountains: false,
    transport: false,
    trees: false,
    toilets: false
};
let searchQuery = '';

// Initialize the application
document.addEventListener('DOMContentLoaded', async function() {
    initializeMap();
    initializeEventListeners();
    await loadParkData();
    await loadFountainData();
    await loadTransportData();
    await loadTreeData();
    await loadBlacktownData(); // auto-load, no filter needed
});

// Initialize Leaflet map
function initializeMap() {
    // Center on Sydney
    map = L.map('map', {
        center: [-33.8688, 151.2093],
        zoom: 13,
        zoomControl: true
    });
    
    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 19
    }).addTo(map);
    
    // Move zoom control to bottom right
    map.zoomControl.setPosition('bottomright');

    // Handle tree layer zoom threshold
    map.on('zoomend', function() {
        if (!currentFilters.trees || !treeClusterLayer) return;
        const zoom = map.getZoom();
        const hint = document.getElementById('trees-zoom-hint');
        if (zoom >= TREE_ZOOM_THRESHOLD) {
            if (!map.hasLayer(treeClusterLayer)) map.addLayer(treeClusterLayer);
            if (hint) hint.style.display = 'none';
        } else {
            if (map.hasLayer(treeClusterLayer)) map.removeLayer(treeClusterLayer);
            if (hint) { hint.textContent = '(zoom in to see)'; hint.style.display = 'block'; }
        }
    });
}

// Load park data from GeoJSON file
async function loadParkData() {
    try {
        const [response, suburbRes] = await Promise.all([
            fetch('data/Parks.geojson'),
            fetch('data/parks-suburbs.json')
        ]);
        if (!response.ok) throw new Error('Failed to load park data');
        
        const geojsonData = await response.json();
        const suburbData = suburbRes.ok ? await suburbRes.json() : {};
        
        // Process the GeoJSON features
        allParks = geojsonData.features.map((feature, index) => {
            const props = feature.properties;
            const geometry = feature.geometry;
            
            // Calculate centroid from geometry
            let lat, lng;
            if (geometry.type === 'Polygon') {
                const coords = geometry.coordinates[0];
                const centroid = calculateCentroid(coords);
                lat = centroid.lat;
                lng = centroid.lng;
            } else if (geometry.type === 'MultiPolygon') {
                const coords = geometry.coordinates[0][0];
                const centroid = calculateCentroid(coords);
                lat = centroid.lat;
                lng = centroid.lng;
            } else {
                lat = -33.8688;
                lng = 151.2093;
            }
            
            return {
                id: props.OBJECTID || index,
                name: props.Name || 'Unnamed Park',
                type: props.Type || 'Unknown',
                suburb: (suburbData[String(props.OBJECTID)] || {}).suburb || '',
                hasPlayground: props.Playgrounds === 'Yes',
                area: props.Shape__Area ? Math.round(props.Shape__Area) : null,
                assetId: props.Asset_ID || '',
                lat: lat,
                lng: lng,
                geometry: geometry
            };
        });
        
        // Initial render
        filteredParks = [...allParks];
        renderMarkers();
        renderResultsList();
        updateResultsCount();
        
        // Fly-in animation on load
        if (markers.length > 0) {
            const group = L.featureGroup(markers);
            map.flyToBounds(group.getBounds().pad(0.1), { duration: 1.4, easeLinearity: 0.25 });
        }
        
    } catch (error) {
        console.error('Error loading park data:', error);
        showError('Unable to load park data. Please ensure the data files are in the correct location.');
    }
}

// Calculate centroid of polygon coordinates
function calculateCentroid(coordinates) {
    let sumLat = 0;
    let sumLng = 0;
    const n = coordinates.length;
    
    coordinates.forEach(coord => {
        sumLng += coord[0];
        sumLat += coord[1];
    });
    
    return {
        lat: sumLat / n,
        lng: sumLng / n
    };
}

// Create custom marker icon
function createMarkerIcon(park) {
    let color = '#2D6A4F'; // Default green
    
    if (park.hasPlayground) {
        color = '#E76F51'; // Orange-red for playgrounds
    } else if (park.type === 'Iconic') {
        color = '#FFD166'; // Yellow for iconic
    } else if (park.type === 'Sportsfield') {
        color = '#F4A261'; // Orange for sportsfields
    } else if (park.type === 'Neighbourhood') {
        color = '#83C5BE'; // Teal for neighbourhood
    }
    
    return L.divIcon({
        className: 'custom-div-marker',
        html: `<div style="
            background-color: ${color};
            width: 24px;
            height: 24px;
            border-radius: 50%;
            border: 3px solid white;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
        "></div>`,
        iconSize: [24, 24],
        iconAnchor: [12, 12],
        popupAnchor: [0, -12]
    });
}

// Render markers on the map
function renderMarkers() {
    // Clear existing markers
    markers.forEach(marker => map.removeLayer(marker));
    markers = [];
    
    filteredParks.forEach(park => {
        const marker = L.marker([park.lat, park.lng], {
            icon: createMarkerIcon(park)
        });
        
        // Create popup content
        const popupContent = createPopupContent(park);
        marker.bindPopup(popupContent, {
            maxWidth: 280,
            className: 'park-popup'
        });
        
        marker.parkData = park;
        marker.addTo(map);
        markers.push(marker);
    });
}

// Create popup HTML content
function createPopupContent(park) {
    const typeClass = park.type.toLowerCase().replace(/\s+/g, '-');
    const facilities = [];
    
    if (park.hasPlayground) facilities.push('Playground');
    if (park.type === 'Sportsfield') facilities.push('Sports Field');
    
    const facilitiesHtml = facilities.length > 0 
        ? `<p style="margin-top: 8px; font-size: 12px;"><strong>Facilities:</strong> ${facilities.join(', ')}</p>`
        : '';
    
    return `
        <div class="popup-content">
            <span class="popup-type">${park.type}</span>
            <h3>${park.name}</h3>
            ${park.area ? `<p>Area: ${park.area.toLocaleString()} m²</p>` : ''}
            ${facilitiesHtml}
            <button class="popup-btn" onclick="openParkModal(${park.id})">View Details</button>
        </div>
    `;
}

// Render the results list in sidebar
function renderResultsList() {
    const resultsList = document.getElementById('results-list');
    
    if (filteredParks.length === 0) {
        resultsList.innerHTML = `
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="11" cy="11" r="8"></circle>
                    <path d="M21 21l-4.35-4.35"></path>
                </svg>
                <p>No parks found matching your criteria.</p>
            </div>
        `;
        return;
    }
    
    resultsList.innerHTML = filteredParks.map(park => `
        <div class="park-card" onclick="selectPark(${park.id})" data-park-id="${park.id}">
            <div class="park-card-header">
                <h4>${park.name}</h4>
                <span class="park-type-badge ${park.type.toLowerCase().replace(/\s+/g, '-')}">${park.type}</span>
            </div>
            <div class="park-card-facilities">
                ${park.hasPlayground ? `
                    <span class="facility-tag">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <path d="M8 14s1.5 2 4 2 4-2 4-2"></path>
                            <line x1="9" y1="9" x2="9.01" y2="9"></line>
                            <line x1="15" y1="9" x2="15.01" y2="9"></line>
                        </svg>
                        Playground
                    </span>
                ` : ''}
                ${park.type === 'Sportsfield' ? `
                    <span class="facility-tag">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="3" y1="12" x2="21" y2="12"></line>
                            <circle cx="12" cy="12" r="3"></circle>
                        </svg>
                        Sports Field
                    </span>
                ` : ''}
                ${park.area ? `
                    <span class="facility-tag">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                        </svg>
                        ${park.area.toLocaleString()} m²
                    </span>
                ` : ''}
            </div>
        </div>
    `).join('');
}

// Update results count
function updateResultsCount() {
    const countEl = document.getElementById('results-count');
    const anyFilterActive = Object.values(currentFilters).some(v => v);
    const count = (!searchQuery && !anyFilterActive) ? filteredParks.length + 1605 : filteredParks.length;
    const label = (!searchQuery && !anyFilterActive) ? 'locations' : `park${count !== 1 ? 's' : ''}`;
    const current = parseInt(countEl.dataset.count || '0');
    if (current === count) return;
    countEl.dataset.count = count;

    const duration = 400;
    const steps = 20;
    const diff = count - current;
    const increment = diff / steps;
    let val = current;
    let step = 0;

    const timer = setInterval(() => {
        step++;
        val += increment;
        countEl.textContent = `${Math.round(val).toLocaleString()} ${label} found`;
        if (step >= steps) {
            countEl.textContent = `${count.toLocaleString()} ${label} found`;
            clearInterval(timer);
        }
    }, duration / steps);
}

// Select a park and zoom to it
function selectPark(parkId) {
    const park = allParks.find(p => p.id === parkId);
    if (!park) return;
    
    // Zoom to the park
    map.setView([park.lat, park.lng], 17);
    
    // Find and open the marker popup
    let marker = markers.find(m => m.parkData.id === parkId);
    if (!marker) {
        marker = L.marker([park.lat, park.lng], { icon: createMarkerIcon(park) });
        marker.bindPopup(createPopupContent(park), { maxWidth: 280, className: 'park-popup' });
        marker.parkData = park;
        marker.addTo(map);
        markers.push(marker);
    }
    marker.openPopup();
    
    // Highlight the card
    document.querySelectorAll('.park-card').forEach(card => {
        card.classList.remove('selected');
    });
    const selectedCard = document.querySelector(`[data-park-id="${parkId}"]`);
    if (selectedCard) {
        selectedCard.classList.add('selected');
    }
}

// Open park modal with details
window.openParkModal = function(parkId) {
    const park = allParks.find(p => p.id === parkId);
    if (!park) return;
    
    const modal = document.getElementById('park-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalType = document.getElementById('modal-type');
    const modalLocation = document.getElementById('modal-location');
    const modalArea = document.getElementById('modal-area');
    const modalFacilities = document.getElementById('modal-facilities-list');
    const modalDirections = document.getElementById('modal-directions');
    
    modalTitle.textContent = park.name;
    modalType.textContent = park.type;
    modalType.className = `park-type-badge ${park.type.toLowerCase().replace(/\s+/g, '-')}`;
    modalLocation.textContent = `Sydney, NSW (${park.lat.toFixed(4)}, ${park.lng.toFixed(4)})`;
    modalArea.textContent = park.area ? `${park.area.toLocaleString()} square meters` : 'Area not available';
    
    // Build facilities list
    const facilities = [];
    if (park.hasPlayground) {
        facilities.push({ name: 'Playground', icon: 'smile' });
    }
    if (park.type === 'Sportsfield') {
        facilities.push({ name: 'Sports Field', icon: 'activity' });
    }
    if (park.type === 'Iconic') {
        facilities.push({ name: 'Iconic Landmark', icon: 'star' });
    }
    
    if (facilities.length === 0) {
        facilities.push({ name: 'Open green space', icon: 'tree' });
    }
    
    modalFacilities.innerHTML = facilities.map(f => `
        <span class="facility-badge">
            ${getIcon(f.icon)}
            ${f.name}
        </span>
    `).join('');
    
    // Set up directions button
    modalDirections.onclick = function() {
        const url = `https://www.google.com/maps/dir/?api=1&destination=${park.lat},${park.lng}`;
        window.open(url, '_blank');
    };
    
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
};

// Get SVG icon by name
function getIcon(name) {
    const icons = {
        smile: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" y1="9" x2="9.01" y2="9"></line><line x1="15" y1="9" x2="15.01" y2="9"></line></svg>',
        activity: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>',
        star: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>',
        tree: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22v-7l-2-2"></path><path d="M17 8v.8A6 6 0 0 1 13.8 20v0H10v0A6.5 6.5 0 0 1 7 8h0a5 5 0 0 1 10 0Z"></path></svg>'
    };
    return icons[name] || '';
}

// Close modal
function closeModal() {
    const modal = document.getElementById('park-modal');
    modal.classList.remove('active');
    document.body.style.overflow = '';
}

// Filter parks based on current filters and search
function applyFilters() {
    const query = searchQuery.toLowerCase();

    filteredParks = allParks.filter(park => {
        if (query) {
            const nameMatch = park.name.toLowerCase().includes(query);
            const typeMatch = park.type.toLowerCase().includes(query);
            const suburbMatch = (park.suburb || '').toLowerCase().includes(query);
            if (!nameMatch && !typeMatch && !suburbMatch) return false;
        }

        const parkFilterKeys = ['playground', 'sports', 'iconic', 'neighbourhood', 'pocket', 'sportsfield'];
        const anyFilterActive = parkFilterKeys.some(k => currentFilters[k]);

        if (anyFilterActive) {
            const matchesPlayground = currentFilters.playground && park.hasPlayground;
            const matchesSports = currentFilters.sports && (park.type === 'Sportsfield' || park.type === 'Sports');
            const matchesIconic = currentFilters.iconic && park.type === 'Iconic';
            const matchesNeighbourhood = currentFilters.neighbourhood && park.type === 'Neighbourhood';
            const matchesPocket = currentFilters.pocket && park.type === 'Pocket';
            const matchesSportsfield = currentFilters.sportsfield && park.type === 'Sportsfield';

            if (!matchesPlayground && !matchesSports && !matchesIconic &&
                !matchesNeighbourhood && !matchesPocket && !matchesSportsfield) {
                return false;
            }
        }

        return true;
    });

    // Also filter overlay items (fountains, transport, blacktown) by search
    if (query) {
        const overlayMatches = allOverlayItems.filter(item => {
            const nameMatch = (item.name || '').toLowerCase().includes(query);
            const subtitleMatch = item.subtitle && item.subtitle.toLowerCase().includes(query);
            const typeMatch = item.type.toLowerCase().includes(query);
            return nameMatch || subtitleMatch || typeMatch;
        });
        renderResultsListWithOverlay(overlayMatches);
    } else {
        renderResultsList();
    }

    renderMarkers();
    if (!searchQuery) updateResultsCount();

    if (markers.length > 0) {
        const group = L.featureGroup(markers);
        map.fitBounds(group.getBounds().pad(0.1));
    }
}

// Render sidebar list including overlay search matches
function renderResultsListWithOverlay(overlayMatches) {
    const resultsList = document.getElementById('results-list');
    const query = searchQuery.toLowerCase();

    // Exclude transport from general location searches
    const filteredOverlay = overlayMatches.filter(item => item.type !== 'Transport');

    const matchedParks = allParks.filter(park =>
        park.name.toLowerCase().includes(query) || park.type.toLowerCase().includes(query) || park.suburb.toLowerCase().includes(query)
    );

    const parkItems = matchedParks.map(park => `
        <div class="park-card" onclick="selectPark(${park.id})" data-park-id="${park.id}">
            <div class="park-card-header">
                <h4>${park.name}</h4>
                <span class="park-type-badge ${park.type.toLowerCase().replace(/\s+/g, '-')}">${park.type}</span>
            </div>
            <div class="park-card-facilities">
                ${park.hasPlayground ? `<span class="facility-tag">Playground</span>` : ''}
                ${park.area ? `<span class="facility-tag">${park.area.toLocaleString()} m²</span>` : ''}
            </div>
        </div>
    `).join('');

    const overlayItems = filteredOverlay.map((item, i) => `
        <div class="park-card" onclick="flyToOverlay(${i},'${item.type}')" style="cursor:pointer;">
            <div class="park-card-header">
                <h4>${item.name}</h4>
                <span class="park-type-badge ${item.type.toLowerCase()}">${item.subtitle.split(' · ')[0]}</span>
            </div>
            <div class="park-card-facilities">
                <span class="facility-tag">${item.subtitle.split(' · ')[1] || item.type}</span>
            </div>
        </div>
    `).join('');

    if (matchedParks.length === 0 && filteredOverlay.length === 0) {
        resultsList.innerHTML = `
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="11" cy="11" r="8"></circle>
                    <path d="M21 21l-4.35-4.35"></path>
                </svg>
                <p>No locations found matching your search.</p>
            </div>`;
        const countEl = document.getElementById('results-count');
        if (countEl) countEl.textContent = '0 results found';
        return;
    }

    const total = matchedParks.length + filteredOverlay.length;
    const countEl = document.getElementById('results-count');
    if (countEl) countEl.textContent = `${total} result${total !== 1 ? 's' : ''} found`;

    window._overlaySearchMatches = filteredOverlay;
    resultsList.innerHTML = parkItems + overlayItems;
}


// Fly to an overlay search result
window.flyToOverlay = function(index, type) {
    const matches = window._overlaySearchMatches;
    if (!matches || !matches[index]) return;
    const item = matches[index];
    map.setView([item.lat, item.lng], 17);
};

// ── Drinking Fountains ───────────────────────────────────────────────────────
async function loadFountainData() {
    try {
        const res = await fetch('data/drinking-fountains.geojson');
        if (!res.ok) throw new Error('Failed to load fountain data');
        const data = await res.json();

        fountainLayer = L.layerGroup();
        data.features.forEach(f => {
            const [lng, lat] = f.geometry.coordinates;
            const p = f.properties;
            const icon = L.divIcon({
                className: 'custom-div-marker',
                html: `<div style="background:#0077B6;width:18px;height:18px;border-radius:50%;border:2px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="white" stroke="none"><path d="M12 22V12M5 12C5 8 8 4 12 4s7 4 7 8M5 12H2a10 10 0 0 0 20 0h-3"/></svg>
                </div>`,
                iconSize: [18, 18], iconAnchor: [9, 9], popupAnchor: [0, -9]
            });
            const marker = L.marker([lat, lng], { icon });
            marker.bindPopup(`
                <div class="popup-content">
                    <span class="popup-type" style="background:#0077B6;">Drinking Fountain</span>
                    <h3>${p.site_name || 'Water Bubbler'}</h3>
                    <p>${p.Suburb || ''}</p>
                    <p style="font-size:11px;color:#666;">${p.Accessible || ''}</p>
                </div>`, { maxWidth: 240 });
            fountainLayer.addLayer(marker);

            // Register for search
            allOverlayItems.push({ name: p.site_name || 'Water Bubbler', subtitle: p.Suburb || '', lat, lng, type: 'Fountain' });
        });
    } catch (e) {
        console.error('Error loading fountain data:', e);
    }
}

// ── Public Transport ─────────────────────────────────────────────────────────
async function loadTransportData() {
    try {
        const res = await fetch('data/public-transports.json');
        if (!res.ok) throw new Error('Failed to load transport data');
        const data = await res.json();

        transportLayer = L.layerGroup();
        // Only show parent stations (1) and bus stops (2)
        const stops = data.filter(s => s.location_type === 1 || s.location_type === 2);
        stops.forEach(s => {
            const isStation = s.location_type === 1;
            const color = isStation ? '#7209B7' : '#9B5DE5';
            const size = isStation ? 22 : 16;
            const icon = L.divIcon({
                className: 'custom-div-marker',
                html: `<div style="background:${color};width:${size}px;height:${size}px;border-radius:${isStation ? '4px' : '50%'};border:2px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;">
                    <svg width="${size*0.5}" height="${size*0.5}" viewBox="0 0 24 24" fill="white" stroke="none"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/></svg>
                </div>`,
                iconSize: [size, size], iconAnchor: [size/2, size/2], popupAnchor: [0, -size/2]
            });
            const marker = L.marker([s.stop_lat, s.stop_lon], { icon });
            marker.bindPopup(`
                <div class="popup-content">
                    <span class="popup-type" style="background:${color};">${isStation ? 'Train Station' : 'Bus Stop'}</span>
                    <h3>${s.stop_name}</h3>
                    ${s.wheelchair_boarding === 1 ? '<p style="font-size:11px;color:#666;">♿ Wheelchair accessible</p>' : ''}
                </div>`, { maxWidth: 240 });
            transportLayer.addLayer(marker);

            // Register for search
            allOverlayItems.push({ name: s.stop_name, subtitle: isStation ? 'Train Station' : 'Bus Stop', lat: s.stop_lat, lng: s.stop_lon, type: 'Transport' });
        });
    } catch (e) {
        console.error('Error loading transport data:', e);
    }
}

// ── Trees ────────────────────────────────────────────────────────────────────
async function loadTreeData() {
    try {
        const res = await fetch('data/trees.geojson');
        if (!res.ok) throw new Error('Failed to load tree data');
        const data = await res.json();

        treeClusterLayer = L.markerClusterGroup({
            maxClusterRadius: 60,
            iconCreateFunction: function(cluster) {
                const count = cluster.getChildCount();
                const size = count > 100 ? 44 : count > 20 ? 36 : 28;
                return L.divIcon({
                    html: `<div style="background:rgba(34,139,34,0.85);width:${size}px;height:${size}px;border-radius:50%;border:2px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;color:white;font-weight:700;font-size:${size > 36 ? 13 : 11}px;">${count}</div>`,
                    className: 'tree-cluster', iconSize: [size, size], iconAnchor: [size/2, size/2]
                });
            }
        });

        data.features.forEach(f => {
            const [lng, lat] = f.geometry.coordinates;
            const p = f.properties;
            const canopy = p.TreeCanopyNS || 2;
            const height = p.TreeHeight || 3;
            // Size marker by canopy, highlight big/old trees
            const isBig = canopy >= 10 || height >= 15 || p.Tree_Age === 'Mature' || p.Tree_Age === 'Over-Mature';
            const size = isBig ? 20 : Math.max(10, Math.min(16, canopy * 1.5));
            const color = isBig ? '#1A5C1A' : '#4CAF50';
            const border = isBig ? '2px solid #FFD700' : '2px solid white';

            const icon = L.divIcon({
                className: 'custom-div-marker',
                html: `<div style="background:${color};width:${size}px;height:${size}px;border-radius:50%;border:${border};box-shadow:0 2px 5px rgba(0,0,0,0.25);"></div>`,
                iconSize: [size, size], iconAnchor: [size/2, size/2], popupAnchor: [0, -size/2]
            });
            const marker = L.marker([lat, lng], { icon });
            marker.bindPopup(`
                <div class="popup-content">
                    <span class="popup-type" style="background:${color};">${isBig ? '🌳 Notable Tree' : 'Tree'}</span>
                    <h3>${p.CommonName || p.SpeciesName || 'Tree'}</h3>
                    <p style="font-size:11px;color:#555;font-style:italic;">${p.SpeciesName || ''}</p>
                    <p style="font-size:12px;">Height: ${height}m &nbsp;|&nbsp; Canopy: ${canopy}m</p>
                    <p style="font-size:11px;color:#666;">${p.TreeType || ''} · ${p.Tree_Age || ''}</p>
                </div>`, { maxWidth: 240 });
            treeClusterLayer.addLayer(marker);
        });
    } catch (e) {
        console.error('Error loading tree data:', e);
    }
}

// ── Toilets (pre-processed lean JSON, clustered) ─────────────────────────────
async function loadToiletData() {
    if (toiletsLoaded || toiletsLoading) return;
    toiletsLoading = true;

    const hint = document.getElementById('toilet-loading-hint');
    if (hint) { hint.textContent = 'Loading toilets...'; hint.style.display = 'block'; }

    try {
        const res = await fetch('data/toilets-sydney.json');
        if (!res.ok) throw new Error('Failed to fetch toilet data');
        const data = await res.json();

        toiletLayer = L.markerClusterGroup({
            maxClusterRadius: 50,
            iconCreateFunction: function(cluster) {
                const count = cluster.getChildCount();
                const size = count > 50 ? 40 : count > 10 ? 32 : 26;
                return L.divIcon({
                    html: `<div style="background:rgba(230,126,34,0.85);width:${size}px;height:${size}px;border-radius:50%;border:2px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;color:white;font-weight:700;font-size:${size > 32 ? 13 : 11}px;">${count}</div>`,
                    className: 'toilet-cluster', iconSize: [size, size], iconAnchor: [size/2, size/2]
                });
            }
        });

        data.forEach(t => {
            const icon = L.divIcon({
                className: 'custom-div-marker',
                html: `<div style="background:#E67E22;width:18px;height:18px;border-radius:4px;border:2px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.3);"></div>`,
                iconSize: [18, 18], iconAnchor: [9, 9], popupAnchor: [0, -9]
            });
            const marker = L.marker([t.lat, t.lng], { icon });
            marker.bindPopup(`
                <div class="popup-content">
                    <span class="popup-type" style="background:#E67E22;">Public Toilet</span>
                    <h3>${t.n || 'Public Toilet'}</h3>
                    <p>${t.t || ''}</p>
                    ${t.h ? `<p style="font-size:11px;color:#666;">${t.h}</p>` : ''}
                    ${t.a === 'True' ? '<p style="font-size:11px;color:#666;">♿ Accessible</p>' : ''}
                    ${t.b === 'True' ? '<p style="font-size:11px;color:#666;">🍼 Baby change</p>' : ''}
                </div>`, { maxWidth: 240 });
            toiletLayer.addLayer(marker);
        });

        toiletsLoaded = true;
        if (hint) hint.style.display = 'none';
        if (currentFilters.toilets) map.addLayer(toiletLayer);

    } catch (e) {
        console.error('Error loading toilet data:', e);
        if (hint) { hint.textContent = '(failed to load)'; hint.style.color = '#c00'; }
    }
    toiletsLoading = false;
}

// ── Blacktown Area Parks & Playgrounds (auto-loads on startup) ───────────────
async function loadBlacktownData() {
    try {
        const res = await fetch('data/blacktown.geojson');
        if (!res.ok) throw new Error('Failed to load Blacktown data');
        const data = await res.json();

        blacktownLayer = L.markerClusterGroup({
            maxClusterRadius: 50,
            iconCreateFunction: function(cluster) {
                const count = cluster.getChildCount();
                const size = count > 100 ? 44 : count > 20 ? 36 : 28;
                return L.divIcon({
                    html: `<div style="background:rgba(220,38,127,0.85);width:${size}px;height:${size}px;border-radius:50%;border:2px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;color:white;font-weight:700;font-size:${size > 36 ? 13 : 11}px;">${count}</div>`,
                    className: 'blacktown-cluster', iconSize: [size, size], iconAnchor: [size/2, size/2]
                });
            }
        });

        data.features.forEach(f => {
            const geom = f.geometry;
            if (!geom || !geom.coordinates) return;
            const [lng, lat] = geom.coordinates;
            const p = f.properties;
            const isPlayground = p.leisure === 'playground';
            const color = isPlayground ? '#DC267F' : '#8B1A6B';
            const size = isPlayground ? 16 : 20;
            const shape = isPlayground ? '50%' : '4px';

            const icon = L.divIcon({
                className: 'custom-div-marker',
                html: `<div style="background:${color};width:${size}px;height:${size}px;border-radius:${shape};border:2px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.3);"></div>`,
                iconSize: [size, size], iconAnchor: [size/2, size/2], popupAnchor: [0, -size/2]
            });

            const marker = L.marker([lat, lng], { icon });
            marker.bindPopup(`
                <div class="popup-content">
                    <span class="popup-type" style="background:${color};">${isPlayground ? '🛝 Playground' : '🌳 Park'} · Blacktown</span>
                    <h3>${p.name || (isPlayground ? 'Playground' : 'Park')}</h3>
                    ${p.website ? `<a href="${p.website}" target="_blank" style="font-size:11px;color:#0077B6;">Visit website</a>` : ''}
                </div>`, { maxWidth: 240 });
            blacktownLayer.addLayer(marker);

            // Register named items for search
            if (p.name) {
                allOverlayItems.push({ name: p.name, subtitle: isPlayground ? 'Playground · Blacktown' : 'Park · Blacktown', lat, lng, type: 'Blacktown' });
            }
        });

        // Auto-show on map without needing a filter
        map.addLayer(blacktownLayer);

    } catch (e) {
        console.error('Error loading Blacktown data:', e);
    }
}

// Initialize event listeners
function initializeEventListeners() {
    // Search input
    const searchInput = document.getElementById('search-input');
    const clearSearchBtn = document.getElementById('clear-search');
    
    searchInput.addEventListener('input', function(e) {
        searchQuery = e.target.value;
        clearSearchBtn.style.display = searchQuery ? 'flex' : 'none';
        applyFilters();
    });
    
    clearSearchBtn.addEventListener('click', function() {
        searchInput.value = '';
        searchQuery = '';
        clearSearchBtn.style.display = 'none';
        applyFilters();
    });
    
    // Filter checkboxes
    const filterCheckboxes = document.querySelectorAll('.filter-checkbox input');
    filterCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            currentFilters[this.value] = this.checked;

            // Handle overlay layers directly (don't go through applyFilters)
            if (this.value === 'fountains') {
                if (fountainLayer) this.checked ? map.addLayer(fountainLayer) : map.removeLayer(fountainLayer);
            } else if (this.value === 'transport') {
                if (transportLayer) this.checked ? map.addLayer(transportLayer) : map.removeLayer(transportLayer);
            } else if (this.value === 'trees') {
                const hint = document.getElementById('trees-zoom-hint');
                if (this.checked) {
                    if (map.getZoom() >= TREE_ZOOM_THRESHOLD) {
                        if (treeClusterLayer) map.addLayer(treeClusterLayer);
                        if (hint) hint.style.display = 'none';
                    } else {
                        if (hint) { hint.textContent = '(zoom in to see)'; hint.style.display = 'block'; }
                    }
                } else {
                    if (treeClusterLayer && map.hasLayer(treeClusterLayer)) map.removeLayer(treeClusterLayer);
                    if (hint) hint.style.display = 'none';
                }
            } else if (this.value === 'toilets') {
                if (this.checked) {
                    loadToiletData();
                } else {
                    if (toiletLayer && map.hasLayer(toiletLayer)) map.removeLayer(toiletLayer);
                }
            } else {
                applyFilters();
            }
        });
    });
    
    // Clear filters button
    const clearFiltersBtn = document.getElementById('clear-filters');
    clearFiltersBtn.addEventListener('click', function() {
        filterCheckboxes.forEach(checkbox => {
            checkbox.checked = false;
            currentFilters[checkbox.value] = false;
        });
        // Remove overlay layers
        if (fountainLayer && map.hasLayer(fountainLayer)) map.removeLayer(fountainLayer);
        if (transportLayer && map.hasLayer(transportLayer)) map.removeLayer(transportLayer);
        if (treeClusterLayer && map.hasLayer(treeClusterLayer)) map.removeLayer(treeClusterLayer);
        if (toiletLayer && map.hasLayer(toiletLayer)) map.removeLayer(toiletLayer);
        const hint = document.getElementById('trees-zoom-hint');
        if (hint) hint.style.display = 'none';
        applyFilters();
    });
    
    // Sidebar toggle
    const sidebar = document.querySelector('.sidebar');
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const sidebarOpenBtn = document.querySelector('.sidebar-open-btn');
    
    sidebarToggle.addEventListener('click', function() {
        sidebar.classList.add('collapsed');
        sidebarOpenBtn.style.display = 'flex';
        setTimeout(() => map.invalidateSize(), 330);
    });
    
    sidebarOpenBtn.addEventListener('click', function() {
        sidebar.classList.remove('collapsed');
        sidebarOpenBtn.style.display = 'none';
        setTimeout(() => map.invalidateSize(), 330);
    });
    
    // Modal close
    const modal = document.getElementById('park-modal');
    const modalClose = modal.querySelector('.modal-close');
    const modalOverlay = modal.querySelector('.modal-overlay');
    
    modalClose.addEventListener('click', closeModal);
    modalOverlay.addEventListener('click', closeModal);
    
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal.classList.contains('active')) {
            closeModal();
        }
    });
    
    // Sidebar resize handle
    const resizeHandle = document.getElementById('sidebar-resize-handle');
    const sidebarEl = document.querySelector('.sidebar');
    let isResizing = false;

    resizeHandle.addEventListener('mousedown', function(e) {
        isResizing = true;
        resizeHandle.classList.add('dragging');
        document.body.style.cursor = 'ew-resize';
        document.body.style.userSelect = 'none';
    });

    document.addEventListener('mousemove', function(e) {
        if (!isResizing) return;
        const newWidth = e.clientX;
        const min = parseInt(getComputedStyle(sidebarEl).minWidth);
        const max = parseInt(getComputedStyle(sidebarEl).maxWidth);
        sidebarEl.style.width = Math.min(max, Math.max(min, newWidth)) + 'px';
    });

    document.addEventListener('mouseup', function() {
        if (!isResizing) return;
        isResizing = false;
        resizeHandle.classList.remove('dragging');
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
    });
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenuBtn && navLinks) {
        mobileMenuBtn.addEventListener('click', function() {
            navLinks.classList.toggle('active');
        });
    }
}

// Show error message
function showError(message) {
    const resultsList = document.getElementById('results-list');
    resultsList.innerHTML = `
        <div class="empty-state" style="color: #E76F51;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="12"></line>
                <line x1="12" y1="16" x2="12.01" y2="16"></line>
            </svg>
            <p>${message}</p>
        </div>
    `;
}